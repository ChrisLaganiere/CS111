// UCLA CS 111 Lab 1 command internals

typedef enum token_type
  {
    AND_TOKEN,            // &&
    SEQUENCE_TOKEN,       // ;
    OR_TOKEN,             // ||
    PIPE_TOKEN,           // |
    SIMPLE_TOKEN,         // any word
    OPEN_PARENS_TOKEN,    // (
    CLOSE_PARENS_TOKEN,   // )
    INPUT_TOKEN,          // <
    OUTPUT_TOKEN,         // >
    NEWLINE_TOKEN,        // \n
    COMMENT_TOKEN,        // #something\n
    UNKNOWN_TOKEN         // anything else
  } token_type_t;

typedef enum command_type
  {
    AND_COMMAND,         // A && B
    SEQUENCE_COMMAND,    // A ; B
    OR_COMMAND,          // A || B
    PIPE_COMMAND,        // A | B
    SIMPLE_COMMAND,      // a simple command
    SUBSHELL_COMMAND,    // ( A )
  } command_type_t;

typedef struct token
{
  token_type_t type;
  int line;
  char *word;
  struct token* next;
  struct token* prev;
} token;

// Data associated with a command.
typedef struct command
{
  enum command_type type;

  // Exit status, or -1 if not known (e.g., because it has not exited yet).
  int status;

  // I/O redirections, or null if none.
  char *input;
  char *output;

  union
  {
    // for AND_COMMAND, SEQUENCE_COMMAND, OR_COMMAND, PIPE_COMMAND:
    struct command *command[2];

    // for SIMPLE_COMMAND:
    char **word;

    // for SUBSHELL_COMMAND:
    struct command *subshell_command;
  } u;
} command;
