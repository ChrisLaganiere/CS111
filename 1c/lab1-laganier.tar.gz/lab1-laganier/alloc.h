// UCLA CS 111 Lab 1 storage allocation
#include <stddef.h>
void *checked_malloc (size_t);
void *checked_realloc (void *, size_t);
void *checked_grow_alloc (void *, size_t *);
